This just wraps github.com/greyblake/whatlang-rs for Python 3.


