from .whatlang import detect_language
